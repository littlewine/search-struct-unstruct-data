Instructions to run the code:

Create the following folders: 
lsi/
lda/
retrievals/
results/
figures/

Run the assignment_ready.ipynb to reproduce all the results. 